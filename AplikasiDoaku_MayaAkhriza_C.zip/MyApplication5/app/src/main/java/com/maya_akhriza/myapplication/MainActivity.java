package com.maya_akhriza.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    MediaPlayer backsound;
    ImageButton ImagePertama;
    ImageButton ImageDua;
    ImageButton ImageTiga;
    ImageButton ImageEmpat;
    ImageButton ImageLima;
    ImageButton ImageEnam;
    ImageButton ImageTujuh;
    ImageButton ImageDelapan;
    ImageButton ImageSembilan;
    ImageButton ImageSepuluh;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(!isConnected(MainActivity.this))

            buildDialog(MainActivity.this).show();
        else{

        }
        setContentView(R.layout.activity_main);

//Memanggil file my_sound pada folder raw
        MediaPlayer backsound= MediaPlayer.create(MainActivity.this,R.raw.backsound);

        //Set looping ke true untuk mengulang audio jika telah selesai
        backsound.setLooping(true);
        //Set volume audio agar berbunyi
        backsound.setVolume(1,1);
        //Memulai audio
        backsound.start();




        ImagePertama = (ImageButton) findViewById(R.id.pertama);
        ImagePertama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaSatu.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageDua = (ImageButton) findViewById(R.id.activity_kedua);
        ImageDua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadActivityDua = new Intent(MainActivity.this, DoaDua.class);
                startActivity(intentLoadActivityDua);
            }
        });
        ImageTiga = (ImageButton) findViewById(R.id.activity_tiga);
        ImageTiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaTiga.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageEmpat = (ImageButton) findViewById(R.id.activity_empat);
        ImageEmpat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaEmpat.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageLima = (ImageButton) findViewById(R.id.activity_lima);
        ImageLima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaLima.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageEnam = (ImageButton) findViewById(R.id.activity_enam);
        ImageEnam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaEnam.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageTujuh = (ImageButton) findViewById(R.id.activity_tujuh);
        ImageTujuh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaTujuh.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageDelapan = (ImageButton) findViewById(R.id.activity_delapan);
        ImageDelapan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaDelapan.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageSembilan = (ImageButton) findViewById(R.id.activity_sembilan);
        ImageSembilan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaSembilan.class);
                startActivity(intentLoadNewActivity);

            }
        });
        ImageSepuluh = (ImageButton) findViewById(R.id.activity_sepuluh);
        ImageSepuluh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, DoaSepuluh.class);
                startActivity(intentLoadNewActivity);

            }
        });
    }

    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("Apakah Yakin Ingin Keluar Nih..?");
        builder.setPositiveButton("Yaps", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                backsound.stop();

                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        int id = item.getItemId();

        if(id==R.id.mnuAlarm)
        {
            Toast.makeText(this, "Settings menu is Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, SettingAlarm.class));

        }
        return super.onOptionsItemSelected(item);
    }

    public boolean isConnected(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();

        if (netinfo != null && netinfo.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting())) return true;
            else return false;
        } else
            return false;
    }
    public AlertDialog.Builder buildDialog(Context c) {

        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        builder.setTitle("Tidak Ada Koneksi..!!");
        builder.setMessage("Kamu membutuhkan Koneksi Untuk Mengakses Audio Doa..!!");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();
            }
        });

        return builder;
    }

}

