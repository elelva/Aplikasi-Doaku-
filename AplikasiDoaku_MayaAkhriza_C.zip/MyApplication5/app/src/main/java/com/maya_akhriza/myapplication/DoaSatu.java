package com.maya_akhriza.myapplication;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class DoaSatu extends AppCompatActivity {

    Button ButtonSatu;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sebelum_tidur);

        String url = "https://firebasestorage.googleapis.com/v0/b/doaku-1017.appspot.com/o/10.%20Doa%20sebelum%20tidur.ogg?alt=media&token=aae3d3a3-2fa3-4ed2-8ba7-18f09196de17";
        final MediaPlayer mp = new MediaPlayer();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
        if (mp != null) {
            mp.reset();
        }
        try {
            mp.setDataSource(url);
        }catch (IOException e){
            e.printStackTrace();
        }
        try {
            mp.prepare();
        }catch (IOException e){
            e.printStackTrace();
        }

        final Button ButtonDua = (Button) findViewById(R.id.play_satu);
        ButtonDua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();
            }
        });
        final Button ButtonDuaStop = (Button) findViewById(R.id.play_satustop);
        ButtonDuaStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                mp.stop();
            }
        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.setting_pertama,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id==R.id.mnuAlarm)
        {
            Toast.makeText(this, "Settings menu is Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, SettingAlarm.class));

        }
        return super.onOptionsItemSelected(item);
    }

}

