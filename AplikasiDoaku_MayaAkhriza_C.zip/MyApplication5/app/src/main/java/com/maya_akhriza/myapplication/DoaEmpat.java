package com.maya_akhriza.myapplication;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class DoaEmpat extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setelah_makan);

        String url = "https://firebasestorage.googleapis.com/v0/b/doaku-1017.appspot.com/o/4.%20Doa%20setelah%20makan.ogg?alt=media&token=228aa7f7-951d-4718-a801-c62f7ac282eb";
        final MediaPlayer mp = new MediaPlayer();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
        if (mp != null) {
            mp.reset();
        }
        try {
            mp.setDataSource(url);
        }catch (IOException e){
            e.printStackTrace();
        }
        try {
            mp.prepare();
        }catch (IOException e){
            e.printStackTrace();
        }

        final Button ButtonEmpat = (Button) findViewById(R.id.play_empat);
        ButtonEmpat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();
            }
        });
        final Button ButtonDuaStop = (Button) findViewById(R.id.play_empatstop);
        ButtonDuaStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                mp.stop();
            }
        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.setting_empat,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id==R.id.mnuAlarm)
        {
            Toast.makeText(this, "Settings menu is Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, SettingAlarm.class));

        }
        return super.onOptionsItemSelected(item);
    }

}



