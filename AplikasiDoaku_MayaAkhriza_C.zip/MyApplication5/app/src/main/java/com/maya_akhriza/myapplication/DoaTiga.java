package com.maya_akhriza.myapplication;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class DoaTiga extends AppCompatActivity {
    Button ButtonTiga;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sebelum_makan);

        String url = "https://firebasestorage.googleapis.com/v0/b/doaku-1017.appspot.com/o/3.%20Doa%20sebelum%20makan.ogg?alt=media&token=1815e283-d897-4a14-8400-3ea66c17e9e4";
        final MediaPlayer mp = new MediaPlayer();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
        if (mp != null) {
            mp.reset();
        }
        try {
            mp.setDataSource(url);
        }catch (IOException e){
            e.printStackTrace();
        }
        try {
            mp.prepare();
        }catch (IOException e){
            e.printStackTrace();
        }

        final Button ButtonDua = (Button) findViewById(R.id.play_tiga);
        ButtonDua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();
            }
        });
        final Button ButtonDuaStop = (Button) findViewById(R.id.play_tigastop);
        ButtonDuaStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                mp.stop();
            }
        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.setting_tiga,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id==R.id.mnuAlarm)
        {
            Toast.makeText(this, "Settings menu is Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, SettingAlarm.class));

        }
        return super.onOptionsItemSelected(item);
    }

}

