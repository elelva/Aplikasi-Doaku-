package com.maya_akhriza.myapplication;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;

public class DoaTujuh extends AppCompatActivity {
    Button ButtonTujuh;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.keluar_rumah);

        String url = "https://firebasestorage.googleapis.com/v0/b/doaku-1017.appspot.com/o/7.%20Doa%20keluar%20rumah.ogg?alt=media&token=17137333-ef45-4955-8f81-4d678133ba00";
        final MediaPlayer mp = new MediaPlayer();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
        if (mp != null) {
            mp.reset();
        }
        try {
            mp.setDataSource(url);
        }catch (IOException e){
            e.printStackTrace();
        }
        try {
            mp.prepare();
        }catch (IOException e){
            e.printStackTrace();
        }

        final Button ButtonDua = (Button) findViewById(R.id.play_tujuh);
        ButtonDua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();
            }
        });
        final Button ButtonDuaStop = (Button) findViewById(R.id.play_tujuhstop);
        ButtonDuaStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                mp.stop();
            }
        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.setting_tujuh,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if(id==R.id.mnuAlarm)
        {
            Toast.makeText(this, "Settings menu is Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, SettingAlarm.class));

        }
        return super.onOptionsItemSelected(item);
    }

}



